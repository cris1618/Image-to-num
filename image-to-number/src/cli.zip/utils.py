import os
from PIL import Image, ImageOps, ImageEnhance, ImageFilter

def preprocess_image(input_path, output_path=None):
    # First open the image
    img = Image.open(input_path).convert("RGB")

    # Smaller resolution (This is to run it on my CPU faster, but on a GPU this part of the code 
    # could be removed and the application should work better with a better image resolution)
    base_width = 1500
    w_percent = (base_width / float(img.size[0]))
    h_size = int((float(img.size[1])* float(w_percent)))
    img = img.resize((base_width, h_size), Image.Resampling.LANCZOS)
    
    # Crop it
    width, height = img.size
    left = int(0.033 * width)
    top = int(0.4 * height)
    right = int(0.75 * width)
    bottom = height
    cropped = img.crop((left, top, right, bottom))

    # Convert grayscale
    gray = cropped.convert("L")

    # Invert the colors
    inverted = ImageOps.invert(gray)

    # aplly gaussian
    blurred = inverted.filter(ImageFilter.GaussianBlur(2))

    # Increase contrast
    enhancer = ImageEnhance.Contrast(blurred)
    processed = enhancer.enhance(10.0)

    if output_path:
        processed.save(output_path)
    
    return processed



if __name__ == "__main__":
    import sys

    if len(sys.argv) < 2:
        print("Not enough arguments")
        sys.exit(1)
    
    input_img = sys.argv[1]
    output_img = None
    if len(sys.argv) > 2:
        output_img = sys.argv[2]
    
    processed_img = preprocess_image(input_img, output_img)
    print("Processing Complete.")
